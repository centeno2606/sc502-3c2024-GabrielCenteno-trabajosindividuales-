<?php
$edad = 20;
if($edad < 18){
    echo "Eres menor de edad";
}elseif ($edad == 18){
    echo "Tienes 18";
}else{
    echo "Eres mayor de edad";
}