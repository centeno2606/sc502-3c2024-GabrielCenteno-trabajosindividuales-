<?php
require('register.php');
echo (userRegistry("juanito1@gmail.com", "123456", "juanito@gmail.com"));