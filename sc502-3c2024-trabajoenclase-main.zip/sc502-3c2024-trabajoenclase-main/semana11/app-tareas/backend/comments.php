<?php
session_start();
header('Content-Type: application/json');

// Verifica si hay una sesión activa
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

// Conexión a la base de datos
$dsn = 'mysql:host=localhost;dbname=todo_app;charset=utf8mb4';
$username = 'root'; 
$password = ''; 

try {
    $pdo = new PDO($dsn, $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database connection failed']);
    exit;
}

// Obtener el método HTTP
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        if (isset($_GET['task_id'])) {
            $taskId = intval($_GET['task_id']);
            $stmt = $pdo->prepare('SELECT * FROM comments WHERE task_id = :task_id');
            $stmt->execute(['task_id' => $taskId]);
            echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
        } else {
            http_response_code(400);
            echo json_encode(['error' => 'Task ID is required']);
        }
        break;

    case 'POST':
        $data = json_decode(file_get_contents('php://input'), true);
        if (isset($data['task_id']) && isset($data['comment'])) {
            $stmt = $pdo->prepare('INSERT INTO comments (task_id, comment) VALUES (:task_id, :comment)');
            $stmt->execute(['task_id' => $data['task_id'], 'comment' => $data['comment']]);
            echo json_encode(['message' => 'Comment added successfully']);
        } else {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid input']);
        }
        break;

    case 'PUT':
        $data = json_decode(file_get_contents('php://input'), true);
        if (isset($data['id']) && isset($data['comment'])) {
            $stmt = $pdo->prepare('UPDATE comments SET comment = :comment WHERE id = :id');
            $stmt->execute(['id' => $data['id'], 'comment' => $data['comment']]);
            echo json_encode(['message' => 'Comment updated successfully']);
        } else {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid input']);
        }
        break;

    case 'DELETE':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $pdo->prepare('DELETE FROM comments WHERE id = :id');
            $stmt->execute(['id' => $id]);
            echo json_encode(['message' => 'Comment deleted successfully']);
        } else {
            http_response_code(400);
            echo json_encode(['error' => 'Comment ID is required']);
        }
        break;

    default:
        http_response_code(405);
        echo json_encode(['error' => 'Method not allowed']);
        break;
}
?>
