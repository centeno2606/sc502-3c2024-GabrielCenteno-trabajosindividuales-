# sc502-3c2024-trabajoenclase
Repositorio para el codigo a desarrollar semana a semana


Este es una mejora, realizada para ver como funciona github desktop

Este un comentario