<?php
//conectarme a la BD, obtener la lista de tareas y crear dinamicamente el HTML que ocupo para mostrar las tareas
    $nombre = "Diego";
    $edad = 25;
    echo "Nombre: $nombre, Edad: $edad";

